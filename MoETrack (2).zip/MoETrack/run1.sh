pwd
cd /mnt/fast/nobackup/users/zt00315
source .bashrc
source activate mplta
export PYTHONPATH=/mnt/fast/nobackup/users/zt00315/Trackers/MPLT-mymain-inerselection:$PYTHONPATH
cd /mnt/fast/nobackup/users/zt00315/Trackers/MPLT-mymain-inerselection

/mnt/fast/nobackup/scratch4weeks/zt00315/anaconda/envs/mplt1/bin/python -m torch.distributed.launch --nproc_per_node=2 lib/train/run_training.py
